Berichtshefthelper

Ein Programm, welches eine Ordnerstruktur erstellt, welche
das Verwalten von Berichtsheften erleichtert und strukturiert.

Anleitung

In das oberste Feld ist der Name der Vorlage einzutragen
(default = Vorlage.docx). Diese Datei wird dann in die einzelnen
Unterordner kopiert, zusammen mit dem passenden Wochendatum.

Das mittlere Feld ist das Beginn-Datum. Von dort fängt das Programm
an die Ordner zu erstellen.

Das untere Feld ist das End-Datum. Dort hört das Programm auf die Ordner
zu erstellen.

Zu beachten ist, das die Monats- und Tag- Angaben nicht funktional sind,
aber immernoch mit anzugeben sind, das wird sich in der Zunkunft vielleicht
noch ändern. Das Programm fängt immer vom Anfang des jeweiligen Jahres an.

Durch einen Klick auf Erstellen startet das Programm. Die Ausführung benötigt
je nach eingestellter Zeitspanne eventuell länger.




Copyright by BotMaster3000 - Creator, Developer and SemiGod;